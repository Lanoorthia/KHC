# King Health Care (เกสัชกร) — เว็บไซต์เวอร์ชันปรับปรุงใหม่

เว็บไซต์สแตติก HTML/CSS/JS ล้วน (ไม่ต้อง build) พร้อม deploy บน Vercel

## โครงสร้างไฟล์
```
index.html          หน้าแรก
products.html        หน้าผลิตภัณฑ์ + ปุ่มสั่งซื้อ Shopee/Lazada/LINE OA/TikTok Shop
about.html            หน้าเกี่ยวกับเรา
distributors.html    หน้าตัวแทนจำหน่าย พร้อมระบบค้นหาตามภาค/ชื่อร้าน
contact.html          หน้าติดต่อเรา พร้อมฟอร์มและแผนที่
css/style.css        สไตล์หลักทั้งเว็บไซต์
js/main.js            เมนูมือถือ, ปุ่มแชทลอย, scroll animation
js/distributors.js    ข้อมูลร้านค้าและตัวกรองค้นหา
vercel.json           การตั้งค่า Vercel (clean URLs)
```

## วิธี Deploy บน Vercel

### วิธีที่ 1: ผ่าน Vercel CLI
```bash
npm i -g vercel
cd king-health-care-site
vercel --prod
```

### วิธีที่ 2: ผ่าน GitHub
1. สร้าง repository ใหม่บน GitHub แล้วอัปโหลดไฟล์ทั้งหมดในโฟลเดอร์นี้
2. เข้า https://vercel.com/new แล้วเลือก Import จาก repository นั้น
3. Framework Preset เลือก **Other** (เพราะเป็น static HTML ล้วน ไม่ต้อง build)
4. กด Deploy — เสร็จแล้ว 🎉

## สิ่งที่ต้องแก้ไขก่อนใช้งานจริง
- **ลิงก์ร้านค้า**: ใส่ลิงก์จริงของ Shopee, Lazada, LINE OA, TikTok Shop แทน `href="#"` ใน `products.html` และปุ่มแชทลอยทุกหน้า
- **โซเชียลมีเดีย**: ใส่ลิงก์ Facebook, Instagram, X, TikTok จริงแทน `href="#"` ใน header/footer ทุกหน้า
- **ฟอร์มติดต่อ**: ปัจจุบันฟอร์มใน `contact.html` เป็นดีโมฝั่ง frontend เท่านั้น ควรเชื่อมกับบริการส่งอีเมลจริง เช่น Formspree, EmailJS หรือ API ของคุณเอง
- **แผนที่**: อัปเดตพิกัด/ที่อยู่ใน iframe Google Maps หากที่อยู่บริษัทเปลี่ยนแปลง
- **ราคาสินค้า**: ตรวจสอบราคาสินค้าที่ใส่ไว้ (Ultra Lip Treatment ฿259, Soft Lip Care ฿199, Lips Care ฿149) ให้ตรงกับราคาขายจริง
- **รูปภาพสินค้า**: ตอนนี้ใช้ gradient พื้นหลังแทนรูปสินค้าจริง แนะนำให้เพิ่มรูปถ่ายสินค้าจริงในโฟลเดอร์ `images/` แล้วแทนที่ใน `.product-media`

## ฟีเจอร์ใหม่ที่เพิ่มเข้ามา
- ปุ่ม Call-to-Action ในหน้าแรก ("สั่งซื้อออนไลน์เลย" / "ดูโปรโมชั่นพิเศษ")
- ปรับฟอนต์เป็น Kanit + Prompt (Google Fonts) ตามที่แนะนำ
- Product Card คลิกดูรายละเอียดพร้อมปุ่มสั่งซื้อ 4 ช่องทางในหน้าเดียว
- ระบบค้นหาตัวแทนจำหน่ายแบบ Dropdown ตามภาค + ค้นหาชื่อร้าน + ลิงก์ดูแผนที่ Google Maps ต่อร้าน
- ปุ่มแชทลอย (Floating Chat Widget) มุมขวาล่างทุกหน้า เชื่อม LINE และโทรออก
- เพิ่ม Trust Signal ในหน้าเกี่ยวกับเรา (Timeline, Value Cards)
- Responsive รองรับมือถือเต็มรูปแบบ พร้อมเมนูแบบ hamburger
